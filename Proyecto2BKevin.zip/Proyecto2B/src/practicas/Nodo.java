package practicas;
public class Nodo {
    int valor;
    Nodo izq;
    Nodo der;
    public Nodo(int _valor){
        this.valor=_valor;
        this.izq=null;
        this.der=null;
    }
}

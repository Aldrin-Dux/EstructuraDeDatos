package proyecto2b;
public class Persona {

    int id;
    String nombre;
    char sexo;

    public Persona(int id, String nombre, char sexo) {
        this.id = id;
        this.nombre = nombre;
        this.sexo = sexo;
    }

}
